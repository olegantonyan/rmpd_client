#!/usr/bin/env bash

echo "Cleaning /var/tmp and /tmp directories"

rm -rf /var/tmp/*
rm -rf /tmp/*

exit 0
