# -*- coding: utf-8 -*-

import logging
import os


import remotecontrol.protocol.incoming.base_command as base_command
import system.wallpaper as wallpaper
import remotecontrol.httpclient as httpclient

log = logging.getLogger(__name__)


class UpdateWallpaper(base_command.BaseCommand):
    def call(self):
        url = self._data['image_url']
        localpath = wallpaper.Wallpaper().custom_image_path()
        self._download_file(url, localpath)
        ok = wallpaper.Wallpaper().load()
        return self._ack(ok)

    def _ack(self, ok):
        return self._sender('ack_' + ('ok' if ok else 'fail')).call(sequence=self._sequence, message='set wallpaper')

    def _download_file(self, url, localpath):
        if os.path.isfile(localpath):
            os.remove(localpath)
        httpclient.download_file(url, localpath)

