#! /usr/bin/python

# Define file locations and other constants in a centralized location.

INTERFACES = '/etc/network/interfaces'
BACKUP = '/etc/network/interfaces.old'
